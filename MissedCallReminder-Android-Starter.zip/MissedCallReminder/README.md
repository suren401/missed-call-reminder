# Missed Call Reminder (starter prototype)

This is an early Android Java prototype, prepared for a personal sideloaded test.

## Important limitations
- Missed-call detection currently listens for notifications posted by the phone/dialer app. Android and Samsung package names and notification wording vary; this must be tested on the target phone.
- Android notification-listener access must be enabled manually in Settings.
- Android notification and background execution policies can delay alerts. Battery optimization may need to be adjusted.
- This prototype's automatic callback check is deliberately basic and is NOT reliable caller-specific matching yet. Do not rely on it until improved and tested.
- Full-screen alerts are not implemented in this starter. Android restricts full-screen intents to eligible use cases.
- Custom contact selection is not implemented yet.
- Exact reminders shorter than 15 minutes may be delayed by Android idle/battery rules.
- READ_CALL_LOG is sensitive and may be restricted by Google Play. This starter is intended for private sideload testing, not Play Store publication.

## Build
Open this repository in a cloud build environment or run `gradle assembleDebug` with Android SDK and JDK 17 installed. GitHub Actions workflow is included.

## First test
1. Install the APK.
2. Open the app and grant notification permission.
3. Tap **Enable missed-call detection** and enable notification access for this app.
4. Grant call-log/notification permissions when prompted.
5. Miss a test call and check whether the app creates a reminder notification.
