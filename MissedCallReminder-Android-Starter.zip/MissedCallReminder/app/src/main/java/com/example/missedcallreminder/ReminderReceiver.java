package com.example.missedcallreminder;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Vibrator;
import android.os.VibrationEffect;
import android.os.VibratorManager;
import android.provider.CallLog;
import android.widget.Toast;
import android.database.Cursor;

public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL = "missed_call_reminders";
    private static final String PREFS = "active_reminders";

    @Override public void onReceive(Context context, Intent intent) {
        String caller = intent.getStringExtra("caller");
        if (caller == null) caller = "Missed call";
        if (isCallbackMade(context, caller)) {
            cancel(context, caller);
            return;
        }
        showReminder(context, caller);
        schedule(context, caller);
    }

    public static void startReminder(Context c, String caller) {
        if (caller == null || caller.trim().isEmpty()) caller = "Missed call";
        c.getSharedPreferences(PREFS, 0).edit().putBoolean(key(caller), true).apply();
        showReminder(c, caller);
        schedule(c, caller);
    }

    private static String key(String caller) { return "active_" + caller.hashCode(); }

    private static void schedule(Context c, String caller) {
        int minutes = c.getSharedPreferences("settings", 0).getInt("interval", 15);
        Intent i = new Intent(c, ReminderReceiver.class).putExtra("caller", caller);
        int request = caller.hashCode();
        PendingIntent pi = PendingIntent.getBroadcast(c, request, i,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        long when = System.currentTimeMillis() + minutes * 60_000L;
        if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        else am.set(AlarmManager.RTC_WAKEUP, when, pi);
    }

    private static void showReminder(Context c, String caller) {
        createChannel(c);
        android.content.SharedPreferences settings = c.getSharedPreferences("settings", 0);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(c, CHANNEL) : new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_dialog_info)
         .setContentTitle("Missed call reminder")
         .setContentText(caller)
         .setAutoCancel(false)
         .setOngoing(true)
         .setContentIntent(PendingIntent.getActivity(c, 0,
             new Intent(c, MainActivity.class), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE))
         .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop",
             PendingIntent.getBroadcast(c, caller.hashCode()+1,
                 new Intent(c, StopReminderReceiver.class).putExtra("caller", caller),
                 PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        if (settings.getBoolean("sound", true)) b.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
        if (settings.getBoolean("vibration", true)) b.setVibrate(new long[]{0, 500, 250, 500});
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(caller.hashCode(), b.build());
    }

    private static void createChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Missed call reminders", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Repeated alerts for missed calls");
            ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    public static void stopAll(Context c) {
        ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).cancelAll();
        c.getSharedPreferences(PREFS, 0).edit().clear().apply();
        Toast.makeText(c, "All reminders stopped.", Toast.LENGTH_SHORT).show();
    }

    private static void cancel(Context c, String caller) {
        ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(caller.hashCode());
        c.getSharedPreferences(PREFS, 0).edit().remove(key(caller)).apply();
    }

    private static boolean isCallbackMade(Context c, String caller) {
        if (!c.getSharedPreferences("settings", 0).getBoolean("autoStop", true)) return false;
        if (c.checkSelfPermission(android.Manifest.permission.READ_CALL_LOG) != android.content.pm.PackageManager.PERMISSION_GRANTED) return false;
        // Basic prototype: compare the latest outgoing call timestamp to the active reminder.
        try (Cursor cur = c.getContentResolver().query(CallLog.Calls.CONTENT_URI,
            new String[]{CallLog.Calls.TYPE, CallLog.Calls.DATE},
            CallLog.Calls.TYPE + "=?",
            new String[]{String.valueOf(CallLog.Calls.OUTGOING_TYPE)},
            CallLog.Calls.DATE + " DESC LIMIT 1")) {
            if (cur != null && cur.moveToFirst()) {
                long date = cur.getLong(1);
                return System.currentTimeMillis() - date < 24L*60*60*1000;
            }
        } catch (Exception ignored) {}
        return false;
    }
}
