package com.example.missedcallreminder;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.os.Build;
import android.text.TextUtils;

public class CallMonitorService extends NotificationListenerService {
    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        String pkg = sbn.getPackageName();
        // Phone-app package names vary by device. Keep this broad and validate on the target phone.
        if (pkg == null || !(pkg.contains("dialer") || pkg.contains("phone"))) return;

        Notification n = sbn.getNotification();
        if (n == null || n.extras == null) return;
        CharSequence titleValue = n.extras.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence textValue = n.extras.getCharSequence(Notification.EXTRA_TEXT);
        String title = titleValue == null ? "" : titleValue.toString();
        String text = textValue == null ? "" : textValue.toString();
        String combined = (title + " " + text).toLowerCase();

        if (combined.contains("missed") || combined.contains("unanswered")) {
            String caller = !TextUtils.isEmpty(title) ? title : text;
            ReminderReceiver.startReminder(this, caller);
        }
    }
}
