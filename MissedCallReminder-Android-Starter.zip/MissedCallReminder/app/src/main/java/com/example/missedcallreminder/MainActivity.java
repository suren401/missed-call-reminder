package com.example.missedcallreminder;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private EditText intervalInput;
    private CheckBox soundBox, vibrationBox, allCallersBox, autoStopBox;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("settings", MODE_PRIVATE);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(28, 32, 28, 24);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("Missed Call Reminder");
        title.setTextSize(25);
        layout.addView(title);

        TextView info = new TextView(this);
        info.setText("Choose how often you want reminders. The first version detects missed-call notifications from your phone app.");
        info.setTextSize(15);
        layout.addView(info);

        intervalInput = new EditText(this);
        intervalInput.setHint("Reminder interval in minutes (15 or more recommended)");
        intervalInput.setInputType(2);
        intervalInput.setText(String.valueOf(prefs.getInt("interval", 15)));
        layout.addView(intervalInput);

        allCallersBox = new CheckBox(this);
        allCallersBox.setText("Remind for all callers");
        allCallersBox.setChecked(prefs.getBoolean("allCallers", true));
        layout.addView(allCallersBox);

        soundBox = new CheckBox(this);
        soundBox.setText("Sound");
        soundBox.setChecked(prefs.getBoolean("sound", true));
        layout.addView(soundBox);

        vibrationBox = new CheckBox(this);
        vibrationBox.setText("Vibration");
        vibrationBox.setChecked(prefs.getBoolean("vibration", true));
        layout.addView(vibrationBox);

        autoStopBox = new CheckBox(this);
        autoStopBox.setText("Stop reminders when I call back (requires call-log permission)");
        autoStopBox.setChecked(prefs.getBoolean("autoStop", true));
        layout.addView(autoStopBox);

        Button save = new Button(this);
        save.setText("Save settings");
        save.setOnClickListener(v -> saveSettings());
        layout.addView(save);

        Button notificationAccess = new Button(this);
        notificationAccess.setText("Enable missed-call detection");
        notificationAccess.setOnClickListener(v ->
            startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")));
        layout.addView(notificationAccess);

        Button permissions = new Button(this);
        permissions.setText("Grant call-log and notification permissions");
        permissions.setOnClickListener(v -> requestNeededPermissions());
        layout.addView(permissions);

        Button stop = new Button(this);
        stop.setText("Stop all reminders");
        stop.setOnClickListener(v -> ReminderReceiver.stopAll(this));
        layout.addView(stop);

        setContentView(layout);
    }

    private void saveSettings() {
        int minutes;
        try { minutes = Integer.parseInt(intervalInput.getText().toString().trim()); }
        catch (Exception e) { minutes = 15; }
        if (minutes < 1) {
            Toast.makeText(this, "Enter at least 1 minute.", Toast.LENGTH_LONG).show();
            return;
        }
        prefs.edit().putInt("interval", minutes)
            .putBoolean("allCallers", allCallersBox.isChecked())
            .putBoolean("sound", soundBox.isChecked())
            .putBoolean("vibration", vibrationBox.isChecked())
            .putBoolean("autoStop", autoStopBox.isChecked()).apply();
        Toast.makeText(this, "Settings saved.", Toast.LENGTH_SHORT).show();
    }

    private void requestNeededPermissions() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
        } else if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_CALL_LOG}, 11);
        } else {
            Toast.makeText(this, "Permissions already granted.", Toast.LENGTH_SHORT).show();
        }
    }
}
