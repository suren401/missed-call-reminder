package com.example.missedcallreminder;

import android.content.*;
import android.app.NotificationManager;
import android.widget.Toast;

public class StopReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        String caller = i.getStringExtra("caller");
        if (caller != null) {
            ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(caller.hashCode());
            c.getSharedPreferences("active_reminders", 0).edit()
                .remove("active_" + caller.hashCode()).apply();
            Toast.makeText(c, "Reminder stopped.", Toast.LENGTH_SHORT).show();
        }
    }
}
